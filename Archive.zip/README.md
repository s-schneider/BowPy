# Seismic-Toolbox: bowPy
Development of a toolbox applicable to seismological array data using Body Waves, containing f-k methods for data reconstruction and filtering


Installation:

- clone/download the repo

- cd into bowPy

- chmod 755 INSTALL.sh

- ./INSTALL.sh



start ipython

voilá
