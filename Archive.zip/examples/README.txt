How to use the example files:

p.pickle can be reconstructed using:

p_reconstructed = pocs_recon(pc, maxiter=40, alpha=0.75)

always start the code in the FK-filter/dev dir!
